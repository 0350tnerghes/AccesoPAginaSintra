package mine.pages;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
@Slf4j
public class HomePage extends BasePage {

    public static final String google = "www.google.com";
    public static final String pageUrl = "https://citaprevia.demohiberus.com/appointment";

    @FindBy(xpath = "//span[contains(text(), 'Cita previa')]//parent::button")
    private WebElement BOTON_CITA_PREVIA;

    @FindBy(xpath = "//span[contains(text(), 'ES')]//parent::button")
    private WebElement BOTON_CAMBIAR_IDIOMA;

    @FindBy(xpath = "//span[contains(text(), 'Te envío un recordatorio a tu correo')]//parent::button")
    private WebElement botonRecordatorioCita;

    @FindBy(xpath = "mat-expansion-panel-header-0")
    private WebElement idMenuLocalizacion;

    @FindBy(xpath = "//mat-radio-group[@name='location']//div[@class='mat-radio-label-content']//div")
    private WebElement TEXT_RADIO_BUTTONS_LOCALIZACION;

    @FindBy(xpath = "//mat-radio-group[@name='department']//div[@class='mat-radio-label-content']//div[1]")
    private WebElement TEXT_RADIO_BUTTONS_OFICINAS;

    @FindBy(xpath = "//mat-radio-group[@name='job']//div[@class='mat-radio-label-content']//div//div//div[1]")
    private WebElement TEXT_RADIO_BUTTONS_SERVICIOS;

    @FindBy(xpath = "//mat-panel-description")
    private WebElement xpathDescripcion;

    @FindBy(xpath = "mat-expansion-panel-header-1")
    private WebElement idMenuOficina;

    @FindBy(xpath = "mat-expansion-panel-header-2")
    private WebElement idMenuServicios;

    @FindBy(xpath = "mat-expansion-panel-header-3")
    private WebElement idMenuFecha;

    @FindBy(xpath = "//span[contains(text(), ':')]")
    private WebElement XpathHoras;

    @FindBy(xpath = "//mwl-calendar-month-cell[contains(@class, 'cal-day-selected')]")
    private WebElement xpathDiaSelecionada;

    @FindBy(xpath = "//mwl-calendar-month-cell")
    private WebElement xpathCeldasCalendario;

    @FindBy(xpath = "//div[@role='columnheader']")
    private WebElement xpathDivDiasSemana;

    @FindBy(xpath = "//input[@name='dniInput']")
    private WebElement xpathInputDni;

    public static final String STRING_DIAS_SEMANA = "Lun.Mar.Mié.Jue.Vie.";

    @FindBy(xpath = "//mat-expansion-panel-header")
    private WebElement xpathTodosLosMenus;

    //Constructor
    public HomePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @Override
    public WebElement getPageLoadedTestElement() {
        return BOTON_CITA_PREVIA;
    }

    //Elementos de la pagina:
    public boolean existeCitaPrevia() {
        boolean existeButon = BOTON_CITA_PREVIA.isDisplayed();
        return existeButon;
    }

    public boolean existeBotonCambiarIdioma() {
        boolean existeButonCambiarIdioima = BOTON_CAMBIAR_IDIOMA.isDisplayed();
        return existeButonCambiarIdioima;
    }

    public boolean existeTEXT_RADIO_BUTTONS_LOCALIZACION() {
        boolean existeTEXT_RADIO_BUTTONS_LOCALIZACION = TEXT_RADIO_BUTTONS_LOCALIZACION.isDisplayed();

        return existeTEXT_RADIO_BUTTONS_LOCALIZACION;
    }

    public boolean existeTEXT_RADIO_BUTTONS_OFICINAS() {
        boolean existeTEXT_RADIO_BUTTONS_OFICINAS = TEXT_RADIO_BUTTONS_OFICINAS.isDisplayed();

        return existeTEXT_RADIO_BUTTONS_OFICINAS;
    }

    public boolean existeTEXT_RADIO_BUTTONS_SERVICIOS() {
        boolean existeTEXT_RADIO_BUTTONS_SERVICIOS = TEXT_RADIO_BUTTONS_SERVICIOS.isDisplayed();

        return existeTEXT_RADIO_BUTTONS_SERVICIOS;
    }

    public boolean existeXpathDescripcion() {
        boolean existeXpathDescripcion = xpathDescripcion.isDisplayed();

        return existeXpathDescripcion;
    }

    public boolean existeIdMenuOficina() {
        boolean existeIdMenuOficina = idMenuOficina.isDisplayed();

        return existeIdMenuOficina;
    }

    public boolean existeIdMenuServicios() {
        boolean existeIdMenuServicios = idMenuServicios.isDisplayed();

        return existeIdMenuServicios;
    }

    public boolean existeIdMenuFecha() {
        boolean existeIdMenuFecha = idMenuFecha.isDisplayed();

        return existeIdMenuFecha;
    }

    public boolean existeXpathTodosLosMenus() {
        boolean existeXpathTodosLosMenus = xpathTodosLosMenus.isDisplayed();

        return existeXpathTodosLosMenus;
    }

    public boolean existeBotonRecordatorioCita() {
        boolean existeBotonRecordatorioCita = botonRecordatorioCita.isDisplayed();

        return existeBotonRecordatorioCita;
    }

    public boolean existeIdMenuLocalizacion() {
        boolean existeIdMenuLocalizacion = idMenuLocalizacion.isDisplayed();

        return existeIdMenuLocalizacion;
    }
}
