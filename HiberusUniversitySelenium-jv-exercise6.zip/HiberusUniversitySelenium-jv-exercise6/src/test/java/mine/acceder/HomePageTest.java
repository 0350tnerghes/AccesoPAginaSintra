package mine.acceder;

import mine.pages.PagesFactory;
import io.github.bonigarcia.wdm.WebDriverManager;
import mine.pages.HomePage;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class HomePageTest {

    public static WebDriver driver;

    public static WebDriverWait wait;

    @Before
    public void setUp() {
        //Paso 0
        WebDriverManager.chromedriver().setup();// Cargar Chromedriver

        driver = new ChromeDriver();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        wait = new WebDriverWait(driver, 10, 500);
        PagesFactory.start(driver);//
    }

    @Test
    public void accederPaginaTest() {
        //Ir a la pagina home https://citaprevia.demohiberus.com/appointment
        PagesFactory pagesFactory = PagesFactory.getInstance();//devuelve la pag factory que tiene la clase dentro ya inicializado
        HomePage homePage = pagesFactory.getHomePage();
        driver.get(homePage.pageUrl);

        Assert.assertTrue(homePage.existeCitaPrevia());
        Assert.assertTrue(homePage.existeBotonCambiarIdioma());
        Assert.assertTrue(homePage.existeBotonRecordatorioCita());


    }

    @Test
    public void validarMenu(){
        PagesFactory pagesFactory = PagesFactory.getInstance();
        HomePage homePage = pagesFactory.getHomePage();

        Assert.assertTrue(homePage.existeIdMenuLocalizacion());
        Assert.assertTrue(homePage.existeTEXT_RADIO_BUTTONS_LOCALIZACION());
        Assert.assertTrue(homePage.existeIdMenuOficina());
        Assert.assertTrue(homePage.existeTEXT_RADIO_BUTTONS_OFICINAS());
        Assert.assertTrue(homePage.existeIdMenuServicios());
        Assert.assertTrue(homePage.existeTEXT_RADIO_BUTTONS_SERVICIOS());
        Assert.assertTrue(homePage.existeIdMenuFecha());
        Assert.assertTrue(homePage.existeXpathDescripcion());
        Assert.assertTrue(homePage.existeXpathTodosLosMenus());
    }



    @After
    public void tearDown() {
        driver.close();
    }

}
