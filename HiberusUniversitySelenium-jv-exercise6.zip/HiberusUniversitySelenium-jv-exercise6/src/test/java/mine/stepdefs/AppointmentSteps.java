package mine.stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import mine.pages.PagesFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import mine.pages.HomePage;
import org.junit.Assert;

@Slf4j

public class AppointmentSteps {
    @Given("the user is on the home page")
    public void the_user_is_on_the_home_page() {
        PagesFactory pf = PagesFactory.getInstance();
        HomePage homePage = pf.getHomePage();
        homePage.navigateTo(HomePage.pageUrl);
        //throw new io.cucumber.java.PendingException();
    }


    @And("the user insert the url to access at the HomePage")
    public void theUserInsertTheUrlToAccessAtTheHomePage() {
        PagesFactory pf = PagesFactory.getInstance();
        log.info("The user provides the url");
        HomePage homePage = pf.getHomePage();
        homePage.navigateTo(HomePage.pageUrl);
        throw new io.cucumber.java.PendingException();
    }

    @When("the home page load")
    public void the_home_page_load() {
        PagesFactory pf = PagesFactory.getInstance();
        HomePage homePage = pf.getHomePage();
        homePage.waitForPageLoad();
        throw new io.cucumber.java.PendingException();
    }

    @Then("the HomePage contain CitaPreva button y CambiarIdioma button")
    public void the_home_page_contain_cita_preva_button_y_cambiar_idioma_button() {
        PagesFactory pf = PagesFactory.getInstance();
        log.info("the HomePage contain CitaPreva button y CambiarIdioma button");
        HomePage homePage = pf.getHomePage();
        if(homePage.existeCitaPrevia()){
            log.info("the HomePage contains CitaPreva button");
        } else {
            log.info("the HomePage doesnt contain CitaPreva button");
        }
        if(homePage.existeBotonCambiarIdioma()){
            log.info("the HomePage contains CambiarIdioma button");
        } else {
            log.info("the HomePage doesnt contain CambiarIdioma button");
        }
        throw new io.cucumber.java.PendingException();
    }

    @Then("The user access successfully HomePage")
    public void the_user_access_successfully_home_page() {
        PagesFactory pf = PagesFactory.getInstance();
        HomePage homePage = pf.getHomePage();
        homePage.waitForPageLoad();
        String currentUrl = PagesFactory.getInstance().getDriver().getCurrentUrl();
        Assert.assertEquals("the URL is not home page", HomePage.pageUrl, currentUrl);
        throw new io.cucumber.java.PendingException();
    }


}
